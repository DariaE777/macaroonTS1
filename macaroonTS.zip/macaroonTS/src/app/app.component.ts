import {Component} from '@angular/core';
import {ProductType} from "./types/product.type";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor() {
    // this.onChange();
  }

  public advantages = [
    {
      title: 'Лучшие продукты',
      description: 'Мы честно готовим макаруны только из натуральных и качественных продуктов. Мы не используем консерванты, ' +
        'ароматизаторы и красители.'
    },
    {
      title: 'Много вкусов',
      description: 'Наша задача – предоставить вам широкое разнобразие вкусов. Вы удивитесь, но у нас более 70 вкусов пироженок.'
    },
    {
      title: 'Бисквитное тесто',
      description: 'Все пирожные готовятся на бисквитном тесте с качественным сливочным маслом 82,5%. В составе нет маргарина и дрожжей!'
    },
    {
      title: 'Честный продукт',
      description: 'Вкус, качество и безопасность наших пирогов подтверждена декларацией о соответствии, которую мы получили 22.06.2016 г.'
    },
  ];
  public products: ProductType[] = [
    {
      image: '1.png',
      title: 'Макарун с малиной',
      orderInfo: {
        quantity: '1 шт.',
        price: '1.70 руб.'
      }
    },
    {
      image: '2.png',
      title: 'Макарун с манго',
      orderInfo: {
        quantity: '1 шт.',
        price: '1.70 руб.'
      }
    },
    {
      image: '3.png',
      title: 'Макарун с ванилью',
      orderInfo: {
        quantity: '1 шт.',
        price: '1.70 руб.'
      }
    },
    {
      image: '4.png',
      title: 'Макарун с фисташками',
      orderInfo: {
        quantity: '1 шт.',
        price: '1.70 руб.'
      }
    },
  ];
  public formValues = {
    productTitle: '',
    customerName: '',
    phone: ''
  };


  public scrollTo(target: HTMLElement): void {
    target.scrollIntoView({behavior: "smooth"});
  }

  public makeOrder(product: ProductType, target: HTMLElement): void {
    this.scrollTo(target);
    this.formValues.productTitle = product.title.toUpperCase();
  }
  public showPresent: boolean = true;
  // onChange():void {
  //   if (window.matchMedia("(max-width: 700px)").matches) {
  //     this.showPresent = false;
  //   } else {
  //     this.showPresent = true;
  //   }
  // }

}
